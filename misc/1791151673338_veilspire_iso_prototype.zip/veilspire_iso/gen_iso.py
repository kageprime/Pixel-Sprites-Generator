#!/usr/bin/env python3
"""Veilspire - iso renderer. Lifts the 2D stick-rig (gen_sprites.py) into 3D and
renders 8 facings with a 2:1 dimetric camera.  Usage: python3 gen_iso.py OUT_DIR [char_id ...]"""
import math, json, os, sys
from PIL import Image, ImageDraw, ImageFilter
import gen_sprites as gs
from gen_sprites import sh, A, INK

gs.pt = lambda p: (p[0], p[1])           # keep sub-pixel coords; the Proxy rounds after projecting

CELL, AX, AY, NF = 96, 48, 74, gs.NF     # cell size, feet anchor inside the cell
DIRS = ['E', 'SE', 'S', 'SW', 'W', 'NW', 'N', 'NE']      # row order, 45 deg apart, clockwise on screen
MOVE = {'E': (1, 0), 'SE': (.707, .707), 'S': (0, 1), 'SW': (-.707, .707),
        'W': (-1, 0), 'NW': (-.707, -.707), 'N': (0, -1), 'NE': (.707, -.707)}
TILE_STEP = {'SE': '+x', 'SW': '+y', 'NW': '-x', 'NE': '-y', 'S': '+x+y', 'N': '-x-y', 'E': '+x-y', 'W': '-x+y'}
ANIMS = [('idle', 6, True), ('walk', 10, True), ('attack', 14, False)]
ATTACK_STYLE = {'maul': ('slam', 3), 'spear': ('thrust', 2), 'staff': ('cast', 3), 'lantern': ('cast', 3),
                'tablet': ('cast', 3)}   # style, hit_frame (default: slash, 2)

# ------------------------------------------------------------ tiny vector helpers
def rd(v): return int(math.floor(v + .5))
def vadd(a, b): return tuple(x + y for x, y in zip(a, b))
def vsub(a, b): return tuple(x - y for x, y in zip(a, b))
def vmul(a, k): return tuple(x * k for x in a)
def vdot(a, b): return sum(x * y for x, y in zip(a, b))
def vavg(ps): return tuple(sum(p[i] for p in ps) / len(ps) for i in range(3))
def clamp(v, a, b): return max(a, min(b, v))
VC = (0, 2 / math.sqrt(5), 1 / math.sqrt(5))             # unit vector toward the camera
_l = (-.5, -.3, .8); LIGHT = vmul(_l, 1 / math.sqrt(vdot(_l, _l)))   # light from upper-left

class Cam:
    """local (f=forward, l=right, u=up) -> world (gx, gy, z) -> screen, for one facing."""
    def __init__(self, deg):
        a = math.radians(deg); self.F = (math.cos(a), math.sin(a)); self.R = (-self.F[1], self.F[0])
    def world(self, f, l, u): return (f * self.F[0] + l * self.R[0], f * self.F[1] + l * self.R[1], u)
    def scr(self, w): return (AX + w[0], AY + w[1] * .5 - w[2])
    def S(self, f, l, u): return self.scr(self.world(f, l, u))
    def Si(self, w): x, y = self.scr(w); return (rd(x), rd(y))
    def gy(self, p): return self.world(*p)[1]

def prof(p, l=0): return (p[0] - gs.CX, l, gs.GROUND - p[1])      # 2D profile px -> local 3D

class Proxy:
    """Lets the original side-view drawing code draw into the iso view: every 2D point is mapped by fn."""
    def __init__(self, d, fn): self.d, self.fn = d, fn
    def P(self, p): x, y = self.fn(p[0], p[1]); return (rd(x), rd(y))
    def line(self, pts, fill=None, width=1): self.d.line([self.P(p) for p in pts], fill=fill, width=width)
    def point(self, xy, fill=None): self.d.point(self.P(xy), fill=fill)
    def polygon(self, pts, fill=None, outline=None): self.d.polygon([self.P(p) for p in pts], fill=fill, outline=outline)
    def ellipse(self, b, fill=None, outline=None):
        x, y = self.P(((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)); rx, ry = rd((b[2] - b[0]) / 2), rd((b[3] - b[1]) / 2)
        self.d.ellipse([x - rx, y - ry, x + rx, y + ry], fill=fill, outline=outline)
    def rectangle(self, b, fill=None, outline=None):
        self.polygon([(b[0], b[1]), (b[2], b[1]), (b[2], b[3]), (b[0], b[3])], fill, outline)

def plane(cam, lat, phi=0, piv=None):   # profile plane at lateral offset `lat`, optionally tilted outward by phi
    if not phi: return lambda x, y: cam.S(*prof((x, y), lat))
    sp, cp = math.sin(phi), math.cos(phi); hf, _, hu = prof(piv, lat)
    def fn(x, y):
        ur = -(y - piv[1]); return cam.S(hf + (x - piv[0]), lat + ur * sp, hu + ur * cp)
    return fn

# outward weapon lean (degrees) so the weapon head doesn't sit on top of the helm
PHI = {'idle': [28] * 6, 'walk': [28] * 6, 'attack': [26, 16, 8, 0, 0, 14]}
def rot_f(v, p):   # rotate a (f,l,u) vector about the forward axis
    return (v[0], v[1] * math.cos(p) + v[2] * math.sin(p), -v[1] * math.sin(p) + v[2] * math.cos(p))

# ------------------------------------------------------------ solids
def newell(pts):
    nx = ny = nz = 0
    for i, a in enumerate(pts):
        b = pts[(i + 1) % len(pts)]
        nx += (a[1] - b[1]) * (a[2] + b[2]); ny += (a[2] - b[2]) * (a[0] + b[0]); nz += (a[0] - b[0]) * (a[1] + b[1])
    return (nx, ny, nz)

def solid(d, cam, verts, faces, col, outline=None):
    """Draw the camera-facing faces of a convex solid, flat-shaded by orientation."""
    W = [cam.world(*v) for v in verts]; cen = vavg(W)
    for fc in faces:
        pts = [W[i] for i in fc]; n = newell(pts)
        if vdot(n, vsub(vavg(pts), cen)) < 0: n = vmul(n, -1)
        L = math.sqrt(vdot(n, n))
        if L < 1e-6: continue
        n = vmul(n, 1 / L)
        if vdot(n, VC) <= .03: continue
        s = clamp(.80 + .30 * vdot(n, LIGHT), .6, 1.12)
        d.polygon([cam.Si(p) for p in pts], fill=A(sh(col, s)), outline=A(outline) if outline else None)

def prism(c0, c1, h0, h1):
    sg = [(1, 1), (1, -1), (-1, -1), (-1, 1)]
    v = [(c0[0] + a * h0[0], c0[1] + b * h0[1], c0[2]) for a, b in sg] + \
        [(c1[0] + a * h1[0], c1[1] + b * h1[1], c1[2]) for a, b in sg]
    return v, [(0, 1, 2, 3), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]

def obox(c, ax, hs):
    v = [tuple(c[i] + sx * hs[0] * ax[0][i] + sy * hs[1] * ax[1][i] + sz * hs[2] * ax[2][i] for i in range(3))
         for sx in (1, -1) for sy in (1, -1) for sz in (1, -1)]
    return v, [(0, 1, 3, 2), (4, 5, 7, 6), (0, 1, 5, 4), (2, 3, 7, 6), (0, 2, 6, 4), (1, 3, 7, 5)]

# ------------------------------------------------------------ one frame
def widths(S):
    t = S['thick']; return dict(ws=2.4 + 1.5 * t, wh=1.6 + .9 * t, hf=1.6 + 1.0 * t)

def limb_shade(g): return .72 + .28 * clamp(.5 + g / 8, 0, 1)

def render_iso(S, anim, f, deg):
    cam = Cam(deg); Wd = widths(S); ws, wh, hf = Wd['ws'], Wd['wh'], Wd['hf']
    P = gs.pose(S, anim, f); K = gs.solve(S, P); phi = math.radians(PHI.get(anim, [0] * 6)[f])
    fig = Image.new('RGBA', (CELL, CELL), (0, 0, 0, 0)); d = ImageDraw.Draw(fig)
    fxl = Image.new('RGBA', (CELL, CELL), (0, 0, 0, 0)); fd = ImageDraw.Draw(fxl)
    F3 = (1, 0, 0); R3 = (0, 1, 0); parts = []
    wl = max(2, rd(S['thick'] * 2.2))
    pel, sho, neck = prof(K['pel']), prof(K['sho']), prof(K['neck'])

    def add(depth, order, fn): parts.append((depth, order, fn))

    # legs (side +1 = character's right = the "front" limb of the profile rig)
    for side, kk, ff in ((1, 'fk', 'ff'), (-1, 'bk', 'bf')):
        l = side * wh; pts = [prof(K['pel'], l), prof(K[kk], l), prof(K[ff], l)]
        g = sum(cam.gy(p) for p in pts) / 3
        add(g, 1, lambda l=l, kk=kk, ff=ff, g=g: gs.draw_leg(Proxy(d, plane(cam, l)), K['pel'], K[kk], K[ff], S, limb_shade(g)))
    # torso
    def torso():
        top = (sho[0], 0, sho[2] + 1); dirv = vsub(top, pel); ln_ = math.sqrt(vdot(dirv, dirv)); dirv = vmul(dirv, 1 / ln_)
        c = S['chest']
        if c in ('plate', 'chitin'):
            v, fc = prism(pel, top, (hf - .2, wh + 1.0), (hf, ws + .3)); solid(d, cam, v, fc, S['pri'], S['sec'])
            belt_top = vadd(pel, vmul(dirv, 2.4))
            v, fc = prism(pel, belt_top, (hf + .5, wh + 1.5), (hf + .5, wh + 1.5)); solid(d, cam, v, fc, S['sec'], None)
            fy, ry = cam.F[1], cam.R[1]
            if fy > .1:     # chest stripe + emblem on the front face
                a = vadd(vadd(pel, vmul(dirv, ln_ - 1.5)), (hf + .1, 0, 0)); b = vadd(vadd(pel, vmul(dirv, 3.2)), (hf + .1, 0, 0))
                d.line([cam.Si(cam.world(*a)), cam.Si(cam.world(*b))], fill=A(S['acc']), width=1)
            if fy < -.1:    # spine line on the back
                a = vadd(vadd(pel, vmul(dirv, ln_ - 1.5)), (-hf - .1, 0, 0)); b = vadd(vadd(pel, vmul(dirv, 3.2)), (-hf - .1, 0, 0))
                d.line([cam.Si(cam.world(*a)), cam.Si(cam.world(*b))], fill=A(S['sec']), width=1)
        else:   # plain body for the rest of the roster (cloth/robe/coat variants come in the roster pass)
            v, fc = prism(pel, top, (hf - .6, wh), (hf - .4, ws - .4)); solid(d, cam, v, fc, S['tone'])
    add(0, 5, torso)
    # head
    h3 = prof(K['head']); hs = cam.S(*h3)
    def head():
        gs.ln(Proxy(d, plane(cam, 0)), K['neck'], K['head'], S['tone'], wl)
        x, y = rd(hs[0]), rd(hs[1]); k = S['helm']
        if k == 'helm':
            d.ellipse([x - 4, y - 4, x + 4, y + 4], fill=A(S['pri']), outline=A(S['sec']))
            if cam.F[1] > -.1:
                a = cam.S(h3[0] + cam.F[0] * 0 + 3.1, -2.0, h3[2] - .3); b = cam.S(h3[0] + 3.1, 2.0, h3[2] - .3)
                d.line([(rd(a[0]), rd(a[1])), (rd(b[0]), rd(b[1]))], fill=A((14, 14, 16)), width=1)
                e = cam.S(h3[0] + 3.6, 0, h3[2] - .3); d.point((rd(e[0]), rd(e[1])), fill=A((14, 14, 16)))
            a = cam.S(h3[0], 0, h3[2] + 4); b = cam.S(h3[0] - 4, 0, h3[2] + 5.5)
            d.line([(rd(a[0]), rd(a[1])), (rd(b[0]), rd(b[1]))], fill=A(S['acc']), width=2)
        else:
            d.ellipse([x - 3, y - 3, x + 3, y + 3], fill=A(S['tone']))
    add(cam.gy(h3) + .05, 6, head)
    # arms (+ pauldrons)
    for side, ee, hh, sd in ((1, 'fe', 'fh', 1.0), (-1, 'be', 'bh', .7)):
        l = side * ws; pts = [prof(K['sho'], l), prof(K[ee], l), prof(K[hh], l)]
        g = sum(cam.gy(p) for p in pts) / 3
        def arm(l=l, ee=ee, hh=hh, g=g, side=side):
            gs.draw_arm(Proxy(d, plane(cam, l)), K['sho'], K[ee], K[hh], S, limb_shade(g))
            if S['pauldron'] or S['chest'] in ('plate', 'chitin'):
                x, y = cam.S(sho[0], l, sho[2] + .5); x, y = rd(x), rd(y)
                d.ellipse([x - 2, y - 2, x + 2, y + 2], fill=A(S['pri']), outline=A(S['sec'])); d.point((x, y - 2), fill=A(S['acc']))
        add(g, 7, arm)
    # right-hand weapon
    kind = S['weapon']; a = math.radians(P['w'])
    dv = rot_f((math.sin(a), 0, -math.cos(a)), phi); pv = rot_f((-math.cos(a), 0, -math.sin(a)), phi)
    lt = rot_f((0, 1, 0), phi); hand = prof(K['fh'], ws)
    def weapon():
        if kind == 'maul':
            at = lambda t, s=0: (hand[0] + dv[0] * t + pv[0] * s, hand[1] + dv[1] * t + pv[1] * s, hand[2] + dv[2] * t + pv[2] * s)
            d.line([cam.Si(cam.world(*at(-7))), cam.Si(cam.world(*at(13)))], fill=A(sh((110, 85, 60), 1)), width=2)
            v, fc = obox(at(14.2), (dv, pv, lt), (3.1, 4.2, 2.7)); solid(d, cam, v, fc, S['pri'], S['acc'])
        elif kind != 'none':
            gs.weapon(Proxy(d, plane(cam, ws, phi, K['fh'])), kind, K['fh'], P['w'], S)
    add(cam.gy(hand) + .3, 8, weapon)
    # shield on the left arm: a real plane that turns with the facing
    if S['offhand'] == 'shield':
        hl = prof(K['bh'], -ws); psi = math.radians(35)
        n = (math.cos(psi), -math.sin(psi), 0); W = (math.sin(psi), math.cos(psi), 0)
        ctr = vadd(hl, (2.5, -1.0, -1.0))
        poly = [(-4, -5), (4, -5), (4, 1), (0, 7), (-4, 1)]
        V = [vadd(ctr, vadd(vmul(W, a_ * 1.15), (0, 0, -b_ * 1.15))) for a_, b_ in poly]
        wn = cam.world(*n)
        def shield():
            front = vdot(wn, VC) > 0; s = clamp(.80 + .30 * vdot(wn, LIGHT), .6, 1.1)
            col = sh(S['sec'], s) if front else sh(S['sec'], .55)
            d.polygon([cam.Si(cam.world(*p)) for p in V], fill=A(col), outline=A(S['acc'] if front else sh(S['acc'], .6)))
            if front:
                a_ = cam.Si(cam.world(*vadd(ctr, (0, 0, 4.5)))); b_ = cam.Si(cam.world(*vadd(ctr, (0, 0, -3.5))))
                d.line([a_, b_], fill=A(S['pri']), width=1); d.point(cam.Si(cam.world(*ctr)), fill=A(S['emi']))
        add(cam.gy(ctr) + .2, 8, shield)
    elif S['offhand'] != 'none':
        hl2 = K['bh']
        add(cam.gy(prof(hl2, -ws)) + .3, 8, lambda: gs.weapon(Proxy(d, plane(cam, -ws)), S['offhand'], K['bh'], P['ow'], S, .8))

    for _, _, fn in sorted(parts, key=lambda t: (round(t[0], 3), t[1])): fn()

    # seal always faces the camera
    gs.draw_seal(Proxy(fd, lambda x, y: (x, y)), S, {'head': hs}, f)
    fx3(fxl, fd, S, P, K, f, cam, ws, phi)
    if P['flash']:
        rgb = Image.blend(fig.convert('RGB'), Image.new('RGB', fig.size, (255, 255, 255)), P['flash']).convert('RGBA')
        rgb.putalpha(fig.split()[3]); fig = rgb
    lum = sum(S['tone']) / 3; rim = (118, 112, 104) if lum < 70 else INK
    dil = fig.split()[3].filter(ImageFilter.MaxFilter(3))
    ol = Image.new('RGBA', fig.size, A(rim)); ol.putalpha(dil)
    out = Image.alpha_composite(ol, fig); out.alpha_composite(fxl)
    return out

def fx3(fxl, fd, S, P, K, f, cam, ws, phi):
    for t in P['fx']:
        Pp = dict(P); Pp['fx'] = [t]; k = t[0]
        tip = gs.tip_of(S, S['weapon'], K['fh'], P['w']); tip = (min(tip[0], gs.CELL - 13), max(tip[1], 9))
        if k in ('arc', 'streak'):
            gs.do_fx(Proxy(fd, plane(cam, ws, phi, K['sho'])), S, Pp, K, f)
        elif k == 'shock':
            c = cam.S(tip[0] - gs.CX, ws, 0); r = 7 + f % 2 * 3
            for rr, al in ((r, 200), (r + 5, 90)):
                fd.ellipse([rd(c[0] - rr), rd(c[1] - rr / 2), rd(c[0] + rr), rd(c[1] + rr / 2)], outline=(200, 190, 170, al))
            for i in range(6):
                a = i * math.pi / 3 + f; x, y = c[0] + (r + 2) * math.cos(a), c[1] + (r + 2) * math.sin(a) / 2
                fd.point((rd(x), rd(y - 2 - i % 3)), fill=(200, 190, 170, 200))
        else:
            anc = {'impact': K['sho'], 'ash': K['pel']}.get(k, tip)
            ax_, ay_ = cam.S(*prof(anc, ws if k not in ('impact', 'ash') else 0))
            gs.do_fx(Proxy(fd, lambda x, y: (ax_ + x - anc[0], ay_ + y - anc[1])), S, Pp, K, f)

def shadow_img(rx=10, ry=5):
    im = Image.new('RGBA', (CELL, CELL), (0, 0, 0, 0)); ImageDraw.Draw(im).ellipse([AX - rx, AY - ry, AX + rx, AY + ry], fill=(0, 0, 0, 70)); return im

def build_sheet(S, anim):
    sheet = Image.new('RGBA', (CELL * NF, CELL * len(DIRS)), (0, 0, 0, 0))
    for r in range(len(DIRS)):
        for f in range(NF): sheet.alpha_composite(render_iso(S, anim, f, r * 45), (f * CELL, r * CELL))
    return sheet

def main():
    out = sys.argv[1] if len(sys.argv) > 1 else 'out'; only = sys.argv[2:] or ['bram_holt']
    os.makedirs(out, exist_ok=True); shadow_img().save(f'{out}/shadow_standard.png')
    meta = dict(game='Veilspire', projection='2:1 dimetric', tile=[64, 32], cell=[CELL, CELL], anchor=dict(x=AX, y=AY), frames=NF,
                directions=DIRS, move_vectors=MOVE, tile_step=TILE_STEP,
                layout='one PNG per animation per character; row = direction (order of "directions"), column = frame',
                animations={}, characters=[])
    for an, fps, lp in ANIMS: meta['animations'][an] = dict(frames=NF, fps=fps, loop=lp)
    for S in gs.ROSTER:
        if S['id'] not in only: continue
        os.makedirs(f"{out}/{S['id']}", exist_ok=True); sheets = {}
        style, hit = ATTACK_STYLE.get(S['weapon'], ('slash', 2))
        for an, _, _ in ANIMS:
            build_sheet(S, an).save(f"{out}/{S['id']}/{an}.png"); sheets[an] = f"{S['id']}/{an}.png"
        meta['characters'].append(dict(id=S['id'], name=S['name'], size_tier='standard', cell=[CELL, CELL],
                                       attack=dict(style=style, hit_frame=hit), shadow='shadow_standard.png', sheets=sheets))
    json.dump(meta, open(f'{out}/veilspire_iso.json', 'w'), indent=2)

if __name__ == '__main__': main(); print('ok')
